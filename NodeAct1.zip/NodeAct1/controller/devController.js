const web ={
    app:(req, res)=>{
        res.render('home');
    },
    login: (req, res) => {
        res.render('login');
    },
    contact: (req, res) => {
        res.render('contact');
    },
    report: (req, res) => {
        res.render('report');
    },
    about: (req, res) => {
        res.render('about');
    }
};
module.exports = web;