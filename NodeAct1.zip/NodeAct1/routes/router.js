const express = require('express');
const router =express.Router();
const dev = require('../controller/devController');

router.get('/', dev.app);
router.get('/login', dev.login);
router.get('/about', dev.about);
router.get('/contact', dev.contact);
router.get('/report', dev.report);
module.exports = router;